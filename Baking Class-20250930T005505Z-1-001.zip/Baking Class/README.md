# Cookie Clicker Downloadable HTML
HEY! YOU! There is a new version available!<br>Find it <a target="_blank" href="https://github.com/Sushi8756/Cookie-Clicker-2.048/">here</a>!<br><br>
2.031 source code for educational purposes. <br>
Download and extract from the "Releases" section.<br>
Or use the <a target="_blank" href="https://sushi8756.github.io/Cookie-Clicker-2.031/">website</a>!<br><br>
Website version loads a bit faster, but can get blocked.<br>
Downloadable HTML version loads a bit slower, but cannot get blocked.<br><br>
I might update this to versions after 2.031 when they come out, but don't count on it.<br>
Credits go Orteil, visit the official website here: http://orteil.dashnet.org/cookieclicker/
<br><br><br><br><br><br><br>
(This is my fist github repo! :D)
